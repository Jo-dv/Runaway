<template>
  <div>
    <footer class="site-footer">
      <div class="container">
        <div class="row">
          <p style="margin-top: 5px; margin-bottom: 5px">@Run Away</p>
        </div>
      </div>
    </footer>
  </div>
</template>

<template>
  <section class="hero-section d-flex justify-content-center align-items-center" id="section_1">
    <div class="container" style="height: 700px">
      <div class="row" style="height: 200px"></div>
      <div class="row">
        <div class="col-lg-8 col-12 mx-auto">
          <h1 class="text-white text-center">Discover. Enjoy Trip !</h1>

          <h6 class="text-center">전국 관광지의 정보를 한번에 찾아보세요.</h6>

          <form method="get" class="custom-form mt-4 pt-2 mb-lg-0 mb-5" role="search">
            <div class="input-group input-group-lg">
              <span class="input-group-text bi-search" id="basic-addon1"> </span>

              <input
                name="keyword"
                type="search"
                class="form-control"
                id="keyword"
                placeholder="서울, 부산, 인천 ..."
                aria-label="Search"
              />

              <button type="submit" class="form-control">Search</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </section>
</template>

<template>
  <div>
    <table class="table table-hover">
      <thead>
        <th class="col-2">번호</th>
        <th class="col-5">제목</th>
        <th class="col-2">작성자</th>
        <th class="col-2">작성일</th>
        <th class="col-1">조회수</th>
      </thead>
      <tbody>
        <tr>
          <td>1</td>
          <td>안녕하세요~ 반갑습니다</td>
          <td>송승준</td>
          <td>2023-10-13</td>
          <td>14</td>
        </tr>
        <tr>
          <td>2</td>
          <td>안녕하세요~ 반갑습니다</td>
          <td>송승준</td>
          <td>2023-10-13</td>
          <td>14</td>
        </tr>
        <tr>
          <td>3</td>
          <td>안녕하세요~ 반갑습니다</td>
          <td>송승준</td>
          <td>2023-10-13</td>
          <td>14</td>
        </tr>
        <tr>
          <td>4</td>
          <td>안녕하세요~ 반갑습니다</td>
          <td>송승준</td>
          <td>2023-10-13</td>
          <td>14</td>
        </tr>
        <tr>
          <td>5</td>
          <td>안녕하세요~ 반갑습니다</td>
          <td>송승준</td>
          <td>2023-10-13</td>
          <td>14</td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

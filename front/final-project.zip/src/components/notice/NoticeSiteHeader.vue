<template>
  <header class="site-header4 d-flex flex-column justify-content-center align-items-center">
    <div class="container">
      <div class="row align-items-center">
        <div class="col-lg-5 col-12">
          <h4 class="text-white">Run Away </h4>
          <h2 class="text-white">Notice</h2>
        </div>
      </div>
    </div>
  </header>
</template>
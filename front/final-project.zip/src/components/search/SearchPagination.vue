<template>
    <nav aria-label="Page navigation example">
        <ul class="pagination justify-content-center mb-4">
          <li class="page-item">
            <a class="page-link" href="#" aria-label="Previous">
              <span aria-hidden="true">Prev</span>
            </a>
          </li>

          <li class="page-item" aria-current="page">
            <a class="page-link" href="#">1</a>
          </li>

          <li class="page-item">
            <a class="page-link" href="#">2</a>
          </li>

          <li class="page-item">
            <a class="page-link" href="#">3</a>
          </li>

          <li class="page-item">
            <a class="page-link" href="#">4</a>
          </li>

          <li class="page-item">
            <a class="page-link" href="#">5</a>
          </li>

          <li class="page-item">
            <a class="page-link" href="#" aria-label="Next">
              <span aria-hidden="true">Next</span>
            </a>
          </li>
        </ul>
      </nav>
</template>
<script setup></script>
<template>
  <div class="col-lg-4 col-md-4 col-12 mt-3 mb-4 mb-lg-0" style="height: 350px">
    <div class="custom-block bg-white shadow-lg">
      <a href="topics-detail.html"
        ><!-- detail 페이지로 이동하도록 수정 필요-->
        <div class="d-flex">
          <div>
            <img src="@/assets/images/korea.jpg" style="max-width: 100%; height: 230px" />
            <h5 class="mb-2" style="margin-top: 30px; margin-bottom: 10px">부산 광안리</h5>
          </div>
        </div>
      </a>
    </div>
  </div>
</template>

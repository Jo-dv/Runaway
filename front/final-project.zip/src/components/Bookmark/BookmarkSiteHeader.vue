<template>
  <header class="site-header d-flex flex-column justify-content-center align-items-center">
    <div class="container">
      <div class="row align-items-center">
        <div class="col-lg-5 col-12">
          <h2 class="text-white">My BookMark</h2>
        </div>
      </div>
    </div>
  </header>
</template>

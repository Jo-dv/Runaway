package com.mycom.enjoy.index.service;

import com.mycom.enjoy.index.dto.InfoDto;

public interface IndexService {
	InfoDto infoTotalCount();
	int visitorTotalCount();
}

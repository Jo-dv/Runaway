package com.mycom.enjoy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnjoytripApplicationTests {

	@Test
	void contextLoads() {
	}

}
